/*--------------------------------------------------------------*/
/* Definición de tipo de dato estructurado en lenguaje C que    */
/* contiene todas las variables de interfaz del F o FB.         */
/*--------------------------------------------------------------*/

   typedef struct Struct_SASE_INT{
      PLC_BOOL EN;
      PLC_INT E0;
      PLC_INT E1;
      PLC_BOOL ENO;
      PLC_INT S0;
   } PLC_FB_Struct_SASE_INT;
	
/*--------------------------------------------------------------*/
/* Prototipo de Función que implementa al F o FB en lenguaje C. */
/*--------------------------------------------------------------*/

   void PLC_FB_SASE_INT( PLC_FB_Struct_SASE_INT * );

/*--------------------------------------------------------------*/
/* Implementación de la Función en lenguaje C que implementa al */
/* F o FB.                                                      */
/*--------------------------------------------------------------*/

   void PLC_FB_SASE_INT( PLC_FB_Struct_SASE_INT *pxPOU ){
      
      // Declaraciones de Tipos de datos del compilador
      
      // Declaraciones de variables del compilador
	  
      // Declaraciones de variables del usuario
      
      // Cuerpo de POU

      /*******[ INICIO DE CODIGO EN DE POU en "pouDecl pouBody cCode: 'codigo' " ]*******/
		if( pxPOU->EN ){ // Todas las POU deben hacer un chequeo EN/ENO
      
         // Si EN = 1, entonces ejecuto el bloque
         pxPOU->S0 = pxPOU->E0 + 2*(pxPOU->E1); // Programa del bloque S0 <= E0 + 2*E1
         
			pxPOU->ENO = 1; // Si no hay errores de ejecucion entonces ENO = 1

			// Si fuese POU Funcion ademas debe copiar su valor de rerotno al CR
         /*
			CR.VALUE.INT = pxPOU->OUT;
			CR.TYPE = INT;
         */
      }
      else{
         pxPOU->ENO = 0; // Si EN = 0, entonces NO ejecuto el bloque y ENO = 0
      }
      /*******[ FIN DE CODIGO EN DE POU en "pouDecl pouBody cCode: 'codigo' " ]**********/
      
   }